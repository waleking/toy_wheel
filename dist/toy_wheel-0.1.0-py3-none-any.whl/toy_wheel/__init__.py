# src/toy_wheel/__init__.py
from .main import hello
