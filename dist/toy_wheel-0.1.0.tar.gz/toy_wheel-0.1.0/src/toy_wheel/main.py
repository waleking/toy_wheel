def hello():
    return "Hello from toy wheel!"
